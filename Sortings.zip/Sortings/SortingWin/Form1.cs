﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sortings;

namespace SortingWin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelectionSort_Click(object sender, EventArgs e)
        {
            label1.Text = String.Empty;
            Sortings.ISort selectionSort = new SelectionSort();

            int[] arry = selectionSort.Execute();

            foreach (int i in arry)
            {
                label1.Text = label1.Text + ", " + i.ToString();
            }

        }

        private void btnBubbleSort_Click(object sender, EventArgs e)
        {
            label1.Text = String.Empty;
            Sortings.ISort bubbleSort = new BubbleSort();

            int[] arry = bubbleSort.Execute();

            foreach (int i in arry)
            {
                label1.Text = label1.Text + ", " + i.ToString();
            }

        }

        private void btnInsertionSort_Click(object sender, EventArgs e)
        {
            label1.Text = String.Empty;
            Sortings.ISort insertionSort = new InsertionSort();

            int[] arry = insertionSort.Execute();

            foreach (int i in arry)
            {
                label1.Text = label1.Text + ", " + i.ToString();
            }
        }

        private void btnQuickSort_Click(object sender, EventArgs e)
        {
            label1.Text = String.Empty;
            Sortings.ISort quickSort = new QuickSort();

            int[] arry = quickSort.Execute();

            foreach (int i in arry)
            {
                label1.Text = label1.Text + ", " + i.ToString();
            }
        }

        private void btnMergeSort_Click(object sender, EventArgs e)
        {
            label1.Text = String.Empty;
            Sortings.ISort mergeSort = new MergeSort();

            int[] arry = mergeSort.Execute();

            foreach (int i in arry)
            {
                label1.Text = label1.Text + ", " + i.ToString();
            }
        }
    }
}
